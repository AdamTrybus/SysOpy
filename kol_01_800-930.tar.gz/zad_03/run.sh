#/!bin/bash
#
echo " "
#
#
./main 4